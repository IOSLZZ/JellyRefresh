//
//  JellyEffectView.m
//  JellyEffectDemo
//
//  Created by admin on 16/5/9.
//  Copyright © 2016年 LZZ. All rights reserved.
//
//取view的坐标及长宽
#define W(view)    view.frame.size.width
#define H(view)    view.frame.size.height
#define X(view)    view.frame.origin.x
#define Y(view)    view.frame.origin.y
#import "JellyEffectView.h"
@interface JellyEffectView ()
{
    CGPoint  _centerPoint;
}
@property (nonatomic, strong) CAShapeLayer *shapeLayer;
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, assign) CGFloat mHeight;

@property (nonatomic, strong) UIView *observerView;            // 参考点
@property (nonatomic,strong)UIColor *springColor;
@property (nonatomic, assign) CGFloat springHeight;
@end
@implementation JellyEffectView
- (instancetype)initWithFrame:(CGRect)frame springColor:(UIColor *)color springHeight:(CGFloat)height
{
    self = [super initWithFrame:frame];
    
    if(self)
    {   self.springColor=color;
        self.springHeight=height;
        [self configShapeLayer];
        [self configObserverView];
        [self configAction];
    }
    
    return self;
}
- (void)configShapeLayer
{
    _shapeLayer = [CAShapeLayer layer];
    _shapeLayer.fillColor = self.springColor.CGColor;
    self.shapeLayer.path      = [self calculatePathWithPoint:CGPointMake(W(self) / 2.f, H(self)
                                                                        / 2.f)].CGPath;
    [self.layer addSublayer:_shapeLayer];
}

- (void)configObserverView
{
    _centerPoint=CGPointMake(W(self)/2.0,self.springHeight);
    _observerView = [[UIView alloc] initWithFrame:CGRectMake(0,0, 4, 4)];
    _observerView.center=_centerPoint;

   // _observerView.backgroundColor = [UIColor redColor];
    [self addSubview:_observerView];
    
}
- (void)configAction
{
    _mHeight = 100;           // 手势移动时相对高度
    _isAnimating = NO;       // 是否处于动效状态
    // 手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanAction:)];
    self.userInteractionEnabled = YES;
    [self addGestureRecognizer:pan];
    
    // CADisplayLink默认每秒运行60次calculatePath是算出在运行期间_curveView的坐标，从而确定_shapeLayer的形状
    _displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(calculatePath)];
    [_displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
   // _displayLink.paused = YES;
}
- (void)handlePanAction:(UIPanGestureRecognizer *)panGesture
{
   
    CGPoint point = [panGesture locationInView:panGesture.view];
    CGPoint calculatePoint = CGPointMake((point.x + _centerPoint.x) / 2.f, (point.y + _centerPoint.y) / 2.f);
    
    //下拉的位移
    CGFloat offsetY = point.y - calculatePoint.y;
    
    
    if (panGesture.state == UIGestureRecognizerStateChanged) {
        _isAnimating = YES;
        self.shapeLayer.path  = [self calculatePathWithPoint:calculatePoint].CGPath;
        self.observerView.center = calculatePoint;
        
        if(self.animatBlock){
            self.animatBlock(_isAnimating);
        }
        
    } else if (panGesture.state == UIGestureRecognizerStateCancelled ||
               panGesture.state == UIGestureRecognizerStateEnded ||
               panGesture.state == UIGestureRecognizerStateFailed) {
        
        [UIView animateWithDuration:1.0 delay:0.0 usingSpringWithDamping:0.25f initialSpringVelocity:0
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             
                             self.observerView.center = _centerPoint;
                             
                         } completion:^(BOOL finished) {
                             if (finished) {
                                 _isAnimating = NO;
                                 
                                 if(self.animatBlock){
                                     self.animatBlock(_isAnimating);
                                 }

#pragma mark 设置下拉刷新
                             
            if (offsetY>=100) {
                                     
            if (self.refreshBlock) {
                self.refreshBlock();
                                    }
                                    }
                             }
                         }];
    }
    
  

}
- (UIBezierPath *)calculatePathWithPoint:(CGPoint)point {
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, 0)];
    [path addLineToPoint:CGPointMake(W(self), 0)];
    [path addLineToPoint:CGPointMake(W(self), _springHeight)];
    
    [path addQuadCurveToPoint:CGPointMake(0, _springHeight)
                  controlPoint:point]; //变化的弧线
   // [path closePath];
    
     return path;
}
- (void)calculatePath
{
    // 由于手势结束时,Ob执行了一个UIView的弹簧动画,把这个过程的坐标记录下来,并相应的画出_shapeLayer形状
    CALayer *layer = _observerView.layer.presentationLayer;
    
     self.shapeLayer.path = [self calculatePathWithPoint:layer.position].CGPath;
}
@end
