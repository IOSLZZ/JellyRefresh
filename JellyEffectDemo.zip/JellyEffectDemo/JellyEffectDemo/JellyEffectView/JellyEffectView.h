//
//  JellyEffectView.h
//  JellyEffectDemo
//
//  Created by admin on 16/5/9.
//  Copyright © 2016年 LZZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JellyEffectView : UIView
- (instancetype)initWithFrame:(CGRect)frame springColor:(UIColor *)color springHeight:(CGFloat)height;
/**<是否正在刷新>*/
@property (nonatomic, assign) BOOL isAnimating;
/**<下拉动画回调>*/
@property (nonatomic,copy) void(^animatBlock)(BOOL isAnimating);
/**<下拉刷新回调>*/
@property (nonatomic,copy) void(^refreshBlock)();
@end
