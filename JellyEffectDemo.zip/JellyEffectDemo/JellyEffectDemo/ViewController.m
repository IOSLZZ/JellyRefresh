//
//  ViewController.m
//  JellyEffectDemo
//
//  Created by admin on 16/5/9.
//  Copyright © 2016年 LZZ. All rights reserved.
//

#import "ViewController.h"
#import "JellyEffectView.h"
#define SYS_DEVICE_WIDTH    ([[UIScreen mainScreen] bounds].size.width)                  // 屏幕宽度
#define SYS_DEVICE_HEIGHT   ([[UIScreen mainScreen] bounds].size.height)                 // 屏幕长度
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    JellyEffectView *jellyEffectView = [[JellyEffectView alloc] initWithFrame:CGRectMake(0, 0, SYS_DEVICE_WIDTH, SYS_DEVICE_HEIGHT/2) springColor:[UIColor colorWithRed:250/255.0 green:250/255.0 blue:250/255.0 alpha:1.0] springHeight:150];
    //BGC
    jellyEffectView.backgroundColor = [UIColor colorWithRed:37/255.0 green:119/255.0 blue:182/255.0 alpha:0.8] ;
    
    [jellyEffectView setAnimatBlock:^(BOOL isAnimating) {
        if (isAnimating) {
            NSLog(@"Loding/准备下拉刷新");
        }
        else{
           NSLog(@"Cancleing/取消下拉刷新");
        }
        
    }];
    [jellyEffectView setRefreshBlock:^{
        NSLog(@"Refreshing/开始下拉刷新");
    }];
    [self.view addSubview:jellyEffectView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
